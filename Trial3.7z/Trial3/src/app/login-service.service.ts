import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from './model/login';
import { Employee } from './model/employeeDetails';
@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  baseUrl = "http://localhost:8888";
  constructor(private http: HttpClient) { }

  getAdmin(): Observable<Login[]>{

    return this.http.get<Login[]>(this.baseUrl +'/getAdmin');
 }

  getEmployee(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.baseUrl + '/getEmployee');
}
  addEmployee(employee: Employee) {
    return this.http.post<Employee>(this.baseUrl + '/addEmployee', employee);
}
  updateEmployee(id: number,employee: Employee): Observable<Object> {
  return this.http.put(`${this.baseUrl}/updateEmployee/${id}`, employee);
}

  getEmployeeById(paramIndex: number) {    
  return this.http.get(`${this.baseUrl}/getEmployeeById/${paramIndex}`);
}

  deleteEmployee(id: number){
    return this.http.delete<any>(`${this.baseUrl}/deleteEmployee/${id}`);
  }
}
